<!DOCTYPE html>
<html lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>आपकी पहचान । वामपंथी या दक्षिणपंथी</title>
    
    <meta name="robots" content="index, follow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="कुछ चंद प्रश्नो के उत्तर देकर आप जान सकते है की आप वामपंथी है या दक्षिणपंथी">
    <meta name="author" content="पवन सिंह बैतुले">
    <meta property="og:url" content="https://www.linkwap.ml">
    <meta property="og:title" content="आपकी पहचान । वामपंथी या दक्षिणपंथी">
    <meta property="og:description" content="कुछ चंद प्रश्नो के उत्तर देकर आप जान सकते है की आप वामपंथी है या दक्षिणपंथी">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="@hardybaitule">
    <meta name="twitter:creator" content="@hardybaitule">
    <link rel="shortcut icon" href="img/favicons/favicon.ico">
    <link rel="icon" href="img/favicons/favicon.png">
    <link rel="stylesheet" href="spectre.min.css">
    <link rel="stylesheet" href="spectre-icons.min.css">
    <link rel="stylesheet" href="spectre-exp.min.css">
    <link rel="manifest" href="/manifest.json">
    <script>
    if (location.protocol != 'https:')
{
 location.href = 'https:' + window.location.href.substring(window.location.protocol.length);
}else{
  if('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
      .then(() => console.log("Service Worker Registered"))
      .catch(e => console.log(e));
  }
}
</script>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Mukta&amp;display=swap">
<style>
body{
font-family: 'Mukta', serif;
    font-size: 19px;
}
  p{

  }
</style>
  </head>
  <body style="padding:2% 5%;" class="contaibner">


<div class="navbar">
<div class="navbar-section">
    <a class="navbar-brand text-bold mr-4" style="padding-left:13px">
        LinkWap.mL</a>

</div>
<div class="navbar-section">
<div class="input-group input-inline"><input class="form-input" type="text" placeholder="search" /><button class="btn btn-primary input-group-btn">Search</button></div>
</div>
</div>

<div class="panel" style="margin-top:12px">
  <div class="panel-header">
    <div class="panel-title text-bold">
    निचे दिए गये प्रश्नों के उत्तर दे कर आप अपने आप को पहचान सकते है की आप वामपंथी है या दक्षिणपंथी ।
</div>
  </div>
  <div class="panel-nav">
    <!-- navigation components: tabs, breadcrumbs or pagination -->
  </div>
  <div class="panel-body">
<div class="divider"></div>
<!-- Question Starts-->
  <div class="form-group">
  <div class=" q1">loading...</div>
  <label class="form-radio">
  <input type="radio" name="q1" value="1">
  <i class="form-icon"></i> 
Yes  </label>
  <label class="form-radio">
  <input type="radio" name="q1" value="0">
  <i class="form-icon"></i> No
  </label>
  </div>
 <!-- question end-->
 <div class="divider"></div>
 
    <!-- Question Starts-->
    <div class="form-group">
    <div class=" q2">loading...</div>
    <label class="form-radio">
    <input type="radio" name="q2" value="1">
    <i class="form-icon"></i> 
Yes    </label>
    <label class="form-radio">
    <input type="radio" name="q2" value="0">
    <i class="form-icon"></i> No
    </label>
    </div>
    <!-- question end-->
    <div class="divider"></div>
    
    <!-- Question Starts-->
    <div class="form-group">
    <div class="q3">loading...</div>
    <label class="form-radio">
    <input type="radio" name="q3" value="1">
    <i class="form-icon"></i> 
Yes    </label>
    <label class="form-radio">
    <input type="radio" name="q3" value="0">
    <i class="form-icon"></i> No
    </label>
    </div>
    <!-- question end-->
    <div class="divider"></div>
    
    <!-- Question Starts-->
    <div class="form-group">
    <div class=" q4">loading...</div>
    <label class="form-radio">
    <input type="radio" name="q4" value="1">
    <i class="form-icon"></i> 
Yes    </label>
    <label class="form-radio">
    <input type="radio" name="q4" value="0">
    <i class="form-icon"></i> No
    </label>
    </div>
    <!-- question end-->

    <!-- contents -->
  </div>
  <div class="panel-footer">
  <progress class="progress" max="100" style="display:none;"></progress>
   <div class="divider"></div>
  <button class="btn btn-block">Check</button>
 <!-- buttons or inputs -->
  </div>
</div>
<hr>
<h4 >
हमसे जुडने के लिए धन्यवाद ।
</h4>

<script src="jquery.js"></script>

<script>var _0x1ac4=["\x76\x61\x6C","\x69\x6E\x70\x75\x74\x5B\x6E\x61\x6D\x65\x3D\x27","\x27\x5D\x3A\x63\x68\x65\x63\x6B\x65\x64","\x64\x61\x74\x61\x2E\x74\x78\x74","\x0A","\x73\x70\x6C\x69\x74","\x74\x65\x78\x74","\x64\x69\x76\x2E\x71","\x67\x65\x74","\x71\x31","\x71\x32","\x71\x33","\x71\x34","\x73\x68\x6F\x77","\x70\x72\x6F\x67\x72\x65\x73\x73","\x68\x69\x64\x65","\x74\x69\x74\x6C\x65","\u0935\u093E\u092E\u092A\u0902\u0925\u0940","\x62\x6F\x64\x79","\u0906\u092A\x20\u0915\u094B\u0908\x20\u0938\u093E\u0927\u093E\u0930\u0923\x20\u092E\u0928\u0941\u0937\u094D\u092F\x20\u0928\u0939\u0940\x20\u0939\u0948\x2C\x20\u0906\u092A\x20\u0909\u0938\x20\u0930\u0902\u0921\u0940\x20\u0915\u0940\x20\u0914\u0932\u093E\u0926\x20\u0939\u0948\x20\u091C\u094B\x20\u0939\u0930\x20\u0917\u0932\u0940\x20\u092E\u094B\u0939\u0932\u094D\u0932\u0947\x20\u092E\u0947\x20\u091C\u093E\u0915\u0930\x20\u091A\u0941\u0926\u0924\u0940\x20\u0930\u0939\u0924\u0940\x20\u0939\u0948\x20\u0964\x20\u0905\u092C\x20\u0938\u0941\u0928\x20\u0932\u0935\u0921\u0947\x2C\x20\u092A\u0924\u0932\u0940\x20\u0917\u0932\u0940\x20\u0938\u0947\x20\u0928\u093F\u0915\u0932\x20\u092F\u0939\u093E\x20\u0938\u0947\x2C\x20\u0914\u0930\x20\u0926\u094B\u092C\u093E\u0930\u093E\x20\u0928\u091D\u0930\x20\u0906\u092F\u093E\x20\u0928\u093E\x20\u0924\u0941\x20\u0924\u094B\x20\u0917\u093E\u0902\u0921\x20\u092E\u0947\x20\u0921\u0902\u0921\u093E\x20\u0918\u0941\u0938\u093E\x20\u0915\u0947\x20\u0939\u093F\u0932\u093E\u090A\u0902\u0917\u093E\x20\u0930\u0902\u0921\u0940\x20\u0915\u0940\x20\u0914\u0932\u093E\u0926\x20\u0964","\x66\x6F\x6F\x74\x65\x72","\u0928\u093F\u0915\u0932\x20\u092D\u094B\u0938\u0921\u0940\x20\u0915\u0947","\u0926\u0915\u094D\u0937\u093F\u0923\u092A\u0902\u0925\u0940","\u092D\u093E\u0930\u0924\x20\u0926\u0947\u0936\x20\u0915\u094B\x20\u0906\u092A\x20\u091C\u0948\u0938\u0947\x20\u0932\u094B\u0917\u094B\x20\u0915\u0940\x20\u091C\u0930\u0941\u0930\u0924\x20\u0939\u0948\x20\u0964\x20\u0906\u092A\x20\u091C\u0948\u0938\u0947\x20\u0932\u094B\u0917\u094B\x20\u0915\u0947\x20\u0909\u092A\u0930\x20\u0939\u0940\x20\u092D\u093E\u0930\u0924\x20\u0915\u093E\x20\u092D\u0935\u093F\u0937\u094D\u092F\x20\u0928\u093F\u0930\u094D\u092D\u0930\x20\u0939\u0948\x20\u0964\x20\u0906\u092A\u0915\u093E\x20\u0927\u0928\u094D\u092F\u0935\u093E\u0926\x20\u0964","\u0939\u092E\u0938\u0947\x20\u091C\u0941\u0921\u0928\u0947\x20\u0915\u0947\x20\u0932\u093F\u090F\x20\u0927\u0928\u094D\u092F\u0935\u093E\u0926","\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x6D\x6F\x64\x61\x6C\x20\x61\x63\x74\x69\x76\x65\x22\x20\x69\x64\x3D\x22\x6D\x6F\x64\x61\x6C\x2D\x69\x64\x22\x3E\x20\x3C\x61\x20\x68\x72\x65\x66\x3D\x22\x23\x63\x6C\x6F\x73\x65\x22\x20\x63\x6C\x61\x73\x73\x3D\x22\x6D\x6F\x64\x61\x6C\x2D\x6F\x76\x65\x72\x6C\x61\x79\x22\x20\x61\x72\x69\x61\x2D\x6C\x61\x62\x65\x6C\x3D\x22\x43\x6C\x6F\x73\x65\x22\x3E\x3C\x2F\x61\x3E\x20\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x6D\x6F\x64\x61\x6C\x2D\x63\x6F\x6E\x74\x61\x69\x6E\x65\x72\x22\x3E\x20\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x6D\x6F\x64\x61\x6C\x2D\x68\x65\x61\x64\x65\x72\x22\x3E\x20\x3C\x61\x20\x68\x72\x65\x66\x3D\x22\x23\x63\x6C\x6F\x73\x65\x22\x20\x63\x6C\x61\x73\x73\x3D\x22\x62\x74\x6E\x20\x62\x74\x6E\x2D\x63\x6C\x65\x61\x72\x20\x66\x6C\x6F\x61\x74\x2D\x72\x69\x67\x68\x74\x22\x20\x61\x72\x69\x61\x2D\x6C\x61\x62\x65\x6C\x3D\x22\x43\x6C\x6F\x73\x65\x22\x3E\x3C\x2F\x61\x3E\x20\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x6D\x6F\x64\x61\x6C\x2D\x74\x69\x74\x6C\x65\x20\x68\x35\x22\x3E\u0906\u092A\x20\x3C\x73\x70\x61\x6E\x20\x63\x6C\x61\x73\x73\x3D\x22\x6C\x61\x62\x65\x6C\x20\x6C\x61\x62\x65\x6C\x2D\x77\x61\x72\x6E\x69\x6E\x67\x22\x3E","\x3C\x2F\x73\x70\x61\x6E\x3E\x20\u0939\u0948\x3C\x2F\x64\x69\x76\x3E\x20\x3C\x2F\x64\x69\x76\x3E\x20\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x6D\x6F\x64\x61\x6C\x2D\x62\x6F\x64\x79\x22\x3E\x20\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x63\x6F\x6E\x74\x65\x6E\x74\x22\x3E\x20","\x20\x3C\x2F\x64\x69\x76\x3E\x20\x3C\x2F\x64\x69\x76\x3E\x20\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x6D\x6F\x64\x61\x6C\x2D\x66\x6F\x6F\x74\x65\x72\x22\x3E\x20","\x20\x3C\x2F\x64\x69\x76\x3E\x20\x3C\x2F\x64\x69\x76\x3E\x20\x3C\x2F\x64\x69\x76\x3E","\x61\x70\x70\x65\x6E\x64","\x72\x65\x6D\x6F\x76\x65","\x2E\x6D\x6F\x64\x61\x6C","\x63\x6C\x69\x63\x6B","\x2E\x62\x74\x6E\x2D\x63\x6C\x65\x61\x72","\x50\x6C\x65\x61\x73\x65\x20\x61\x6E\x73\x77\x65\x72\x20\x61\x6C\x6C\x20\x71\x75\x65\x73\x74\x69\x6F\x6E\x73","\x62\x75\x74\x74\x6F\x6E"];function rv(_0x409bx2){return $(_0x1ac4[1]+ _0x409bx2+ _0x1ac4[2])[_0x1ac4[0]]()}function rn(_0x409bx2){return Number($(_0x1ac4[1]+ _0x409bx2+ _0x1ac4[2])[_0x1ac4[0]]())}$(function(){$[_0x1ac4[8]](_0x1ac4[3],function(_0x409bx4){var _0x409bx5=_0x409bx4[_0x1ac4[5]](_0x1ac4[4]);for(i= 0;i< 5;i++){$(_0x1ac4[7]+ i)[_0x1ac4[6]](_0x409bx5[i- 1])}})});$(_0x1ac4[35])[_0x1ac4[32]](function(){if(rv(_0x1ac4[9])&& rv(_0x1ac4[10])&& rv(_0x1ac4[11])&& rv(_0x1ac4[12])){$(_0x1ac4[14])[_0x1ac4[13]]();setTimeout(function(){$(_0x1ac4[14])[_0x1ac4[15]](300);var _0x409bx6=rn(_0x1ac4[9])+ rn(_0x1ac4[10])+ rn(_0x1ac4[11])+ rn(_0x1ac4[12]);if(_0x409bx6< 3){data= [];data[_0x1ac4[16]]= _0x1ac4[17];data[_0x1ac4[18]]= _0x1ac4[19];data[_0x1ac4[20]]= _0x1ac4[21]}else {data= [];data[_0x1ac4[16]]= _0x1ac4[22];data[_0x1ac4[18]]= _0x1ac4[23];data[_0x1ac4[20]]= _0x1ac4[24]};$(_0x1ac4[18])[_0x1ac4[29]](_0x1ac4[25]+ data[_0x1ac4[16]]+ _0x1ac4[26]+ data[_0x1ac4[18]]+ _0x1ac4[27]+ data[_0x1ac4[20]]+ _0x1ac4[28]);$(_0x1ac4[33])[_0x1ac4[32]](function(){$(_0x1ac4[31])[_0x1ac4[30]]()})},2000)}else {alert(_0x1ac4[34])}})
</script>
	
	

  </body>
</html>
